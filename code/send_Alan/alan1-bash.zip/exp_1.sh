#!/bin/bash

    cd /home/jpierre/v2/new_runs/Alan/Alan1/master-thesis_noisy_classic_dt-0.001_lr-0.005_batch-16_encoder-no-encoder__dropout-no-dropout_update-data-basline-model
    eval "$(conda shell.bash hook)"
    conda activate myenvPy
    python training_main.py
    
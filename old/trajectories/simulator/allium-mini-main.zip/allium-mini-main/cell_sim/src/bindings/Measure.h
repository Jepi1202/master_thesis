//
// Created by Namid Shatil on 7/21/20.
//

#ifndef CAPMD_MEASURE_H
#define CAPMD_MEASURE_H


class Measure {

};


#endif //CAPMD_MEASURE_H
